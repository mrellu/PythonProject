import time
from functools import wraps
import logging

logger = logging.getLogger(__name__)
logging.basicConfig(filename="logsample.log",level=logging.DEBUG)


def timer(func):
    wraps(func)

    def wrapper_timer(*args, **kwargs):
            start_time = time.perf_counter()
            value = func(*args, **kwargs)
            end_time = time.perf_counter()
            run_time = end_time - start_time
            print(f"Finished function {func.__name__!r} in {run_time:.4f} secs")
            logger.debug("{} ran in {}s".format(func.__name__, run_time))
            return value

    return wrapper_timer