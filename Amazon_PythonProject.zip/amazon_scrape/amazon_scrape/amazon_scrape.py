from bs4 import BeautifulSoup
from user_agent import generate_user_agent
import requests
import json
import csv
import re
import sys
from decorator import timer
from bs4 import BeautifulSoup
import requests
from decorator import timer
from selenium import webdriver
from selenium.webdriver.support.ui import Select

#list of books from python books page
@timer
def amazon_scrap():
      try:
           filename = 'amazon_scrap'
           headers = {'User-Agent': generate_user_agent(device_type="desktop", os=('mac', 'linux'))}
           url = "https://www.amazon.com/s?k=python+books&ref=nb_sb_noss_1"
           r = requests.get(url, headers=headers)
           soup = BeautifulSoup(r.content, "lxml")
           books =list()
           
           with open(f'./csv/{filename}.csv', 'w') as file:
                     for i in soup.find_all('span',class_='a-size-medium a-color-base a-text-normal'):
                          books.append(i.get_text())
                     #file.write(f'{i.get_text()}\n')     
                     for j in books:
                          file.write(f'{j}\n')
                     

           with open(f'./json/{filename}.json', 'w') as file:
                     for i in soup.find_all('span',class_='a-size-medium a-color-base a-text-normal'):
                          books.append(i.get_text())
                          #file.write(f'{i.get_text()}\n')     
                     for j in books:
                          file.write(f'{j}\n')
                      

           return books

      except:
           print("Oops!",sys.exc_info()[0],"occured.")
           print("Next entry.")



# top most review
@timer
def amazon_pdt_review():
           try:
                filename = 'amazon_pdt_review'
                headers = {'User-Agent': generate_user_agent(device_type="desktop", os=('mac', 'linux'))}
                with open(f'./csv/{filename}.csv', 'w') as file:
                     url = "https://www.amazon.com/Python-Crash-Course-Hands-Project-Based/dp/1593276036/"
                     r = requests.get(url, headers=headers)
                     soup = BeautifulSoup(r.content, "lxml")
                     detail=soup.find('span',class_='a-size-base review-text')
                     review = detail.get_text()
                     file.write(f'{review}\n')
                                
                with open(f'./json/{filename}.json', 'w') as file:
                     url = "https://www.amazon.com/Python-Crash-Course-Hands-Project-Based/dp/1593276036/"
                     r = requests.get(url, headers=headers)
                     soup = BeautifulSoup(r.content, "lxml")
                     detail=soup.find('span',class_='a-size-base review-text')
                     review = detail.get_text()
                     file.write(f'{review}\n')               
                


                return review

           except:
                print("Oops!",sys.exc_info()[0],"occured.")
                print("Next entry.")




# product details
@timer
def amazon_pdt_detail():
      try:
          #details = list()
           filename='amazon_pdt_detail'
           headers = {'User-Agent': generate_user_agent(device_type="desktop", os=('mac', 'linux'))}
           url = "https://www.amazon.com/dp/1593276036"
           r = requests.get(url, headers=headers)
           soup = BeautifulSoup(r.content, "lxml")
           with open(f'./csv/{filename}.csv', 'w') as file:
                for ul_tags in soup.findAll('div',attrs={'class': 'content'}):
                     for li_tags in ul_tags.findAll('li'):
                          value = li_tags.get_text()
                          file.write(f'{value}\n')
                          #print(value)
                         
           with open(f'./json/{filename}.json', 'w') as file:
                for ul_tags in soup.findAll('div',attrs={'class': 'content'}):
                     for li_tags in ul_tags.findAll('li'):
                          value = li_tags.get_text()
                          file.write(f'{value}\n')
                          #print(value)                
           return value

      except: 
           print("Oops!",sys.exc_info()[0],"occured.")
           print("Next entry.")



                     


# top 100 sellers 
@timer
def amazon_top_seller():
      try:
           filename = 'amazon_top_seller'
           headers = {'User-Agent': generate_user_agent(device_type="desktop", os=('mac', 'linux'))}
           url = "https://www.amazon.com/best-sellers-books-Amazon/zgbs/books"
           r = requests.get(url, headers=headers)
           soup = BeautifulSoup(r.content, "lxml")
           books = list()
           for i in soup.find_all('div', class_='p13n-sc-truncate p13n-sc-line-clamp-1'):
                books.append(i.get_text())
           with open(f'./csv/{filename}.csv', 'w') as file:
                for j in books:
                     file.write(f'{j}')

           for i in soup.find_all('div', class_='p13n-sc-truncate p13n-sc-line-clamp-1'):
                books.append(i.get_text())
           with open(f'./json/{filename}.json', 'w') as file:
                for j in books:
                     file.write(f'{j}')
           return books

      except:
           print("Oops!",sys.exc_info()[0],"occured.")
           print("Next entry.")


            

# recent review
@timer
def recently_review():
          filename = 'recently_review'
          url = 'https://www.amazon.com/dp/1593276036'
          driver = webdriver.PhantomJS()
          driver.get("https://www.amazon.com/dp/1593276036")

          select = Select(driver.find_element_by_id('cm-cr-sort-dropdown'))
          select.select_by_value('recent')
          headers = {
              'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36'}
          # r = requests.get(url, headers=headers)
          soup = BeautifulSoup(driver.page_source, "lxml")
          reviews = list()
          for i in soup.find_all('div', class_='a-expander-content reviewText review-text-content a-expander-partial-collapse-content'):
              reviews.append(i.get_text())
          with open(f'./csv/{filename}.csv', 'w') as file:
                  for i in reviews:
                      file.write(f'{i}\n')

          with open(f'./json/{filename}.json', 'w') as file:
                   for i in reviews:
                        file.write(f'{i}\n')





#product book list 
@timer
def detail_info():
      try:
           filename = 'detail_info'
           headers = {'User-Agent': generate_user_agent(device_type="desktop", os=('mac', 'linux'))}
           url = "https://www.amazon.com/Python-Crash-Course-Hands-Project-Based/dp/1593276036/"
           r = requests.get(url, headers=headers)
           soup = BeautifulSoup(r.content, "lxml")
           with open(f'./csv/{filename}.csv', 'w') as file:
                detail = soup.find('span',class_='a-size-large')
                c = detail.get_text()
                file.write(f'{c}\n')
           with open(f'./csv/{filename}.csv', 'a') as file:
                ratings = soup.find('span',class_='reviewCountTextLinkedHistogram noUnderline')
                dat = soup.find('span',class_='a-size-base a-color-secondary review-date')
                types = ratings.get_text()
                file.write(f'{types}')
                types2 = dat.get_text()
                file.write(f'{types2}')

                '''for (k, j) in zip(ratings,dat):
                     types.append(k.get_text())
                     types2.append(j.get_text())
                     file.write(f'{types}')
                     file.write(f'{types2}')'''
                p = list()
                q = list()
                types = list()
                types2 = list()
           with open(f'./csv/{filename}.csv', 'a') as file:
                p = soup.find_all('span',class_='a-size-small a-color-base')
                q = soup.find_all('span',class_='a-size-medium a-color-price offer-price a-text-normal')
                #file.write(f'ratings - {ratings.get_text()}\n')
                for (k, j) in zip(p, q):
                     types.append(k.get_text())
                     types2.append(j.get_text())
                     file.write(f'{types}')
                     file.write(f'{types2}')
                     #output_csv(filename, types, filename)

           with open(f'./json/{filename}.json', 'w') as file:
                detail = soup.find('span',class_='a-size-large')
                c = detail.get_text()
                file.write(f'{c}\n')
           with open(f'./json/{filename}.json', 'a') as file:
                ratings = soup.find('span',class_='reviewCountTextLinkedHistogram noUnderline')
                dat = soup.find('span',class_='a-size-base a-color-secondary review-date')
                types = ratings.get_text()
                file.write(f'{types}')
                types2 = dat.get_text()
                file.write(f'{types2}')
                
                '''for (k, j) in zip(ratings,dat):
                     types.append(k.get_text())
                     types2.append(j.get_text())
                     file.write(f'{types}')
                     file.write(f'{types2}')'''
                p = list()
                q = list()
                types = list()
                types2 = list()
           with open(f'./json/{filename}.json', 'a') as file:
                p = soup.find_all('span',class_='a-size-small a-color-base')
                q = soup.find_all('span',class_='a-size-medium a-color-price offer-price a-text-normal')
                #file.write(f'ratings - {ratings.get_text()}\n')
                for (k, j) in zip(p, q):
                     types.append(k.get_text())
                     types2.append(j.get_text())
                     file.write(f'{types}')
                     file.write(f'{types2}')
                     #output_csv(filename, types, filename)
           return q

      except:
           print("Oops!",sys.exc_info()[0],"occured.")
           print("Next entry.")


           

          





if __name__ == '__main__':
      recently_review()
      amazon_scrap()
      amazon_pdt_review()
      amazon_pdt_detail()
      detail_info()
      amazon_top_seller()
      

