import argparse

from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import orm, exc

app = Flask(__name__)

database_file = "sqlite:///books.db"
app.config["SQLALCHEMY_DATABASE_URI"] = database_file
db = SQLAlchemy(app)


class Books(db.Model):
    book = db.Column(db.String(80),
                       unique=True,
                       nullable=False,
                       primary_key=True)


def __repr__(self):
    return "<Title : {}>".format(self.title)


db.create_all()


@app.route("/", methods=["GET", "POST"])
def home():
    if request.form:
        book = Books(book=request.form.get("book"))
        db.session.add(book)
        db.session.commit()
    buks = Books.query.all()
    return render_template("book.html ", buks=buks)


@app.route("/update", methods=["GET", "POST"])
def update():
    newname = request.form.get("newname")
    oldname = request.form.get("oldname")
    bookat = Books.query.filter_by(book=oldname).first()
    bookat.book = newname
    db.session.commit()
    return redirect("/")


@app.route("/delete", methods=["POST"])
def delete():
    book = request.form.get("book")
    delbook = Books.query.filter_by(book=book).first()
    print(delbook)
    db.session.delete(delbook)
    db.session.commit()
    return redirect("/")


def Main():
    parser = argparse.ArgumentParser(description='web app ---> amazon.com')
    args = parser.parse_args()


if __name__ == '__main__':
    app.run()
